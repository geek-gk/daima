#include <rclcpp/rclcpp.hpp>
#include <cema_cpp/msg/ImageData.hpp>
#include <semaphore.h>
#include <iostream>
#include <sys/mman.h>
#include <unistd.h>
#include <fcntl.h>
#include <string>
#include <sstream>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <jpeglib.h>  
#define MJPEG_PORT 8000
#define SHM_SIZE 4096
#define SHM_NAME "/camera_shm"
class WebVideoServer : public rclcpp::Node {
public:
    WebVideoServer() : Node("web_video_server") {
        //订阅话题camera_image
        subscriber_ = this->create_subscription<ros2_camera_streamer::msg::ImageData>(
            "camera_image", 1000, std::bind(&WebVideoServer::image_callback, this, std::placeholders::_1));
        // 打开共享内存
        shm_fd_ = shm_open(SHM_NAME, O_RDONLY, 0666);
        if (shm_fd_ == -1) {
            RCLCPP_ERROR(this->get_logger(), "Failed to open shared memory");
            return;
        }
        //映射共享内存 (mmap)代码通过 mmap 将其映射到进程的地址空间，指定该内存为只读（PROT_READ），并且进程间共享（MAP_SHARED）。如果映射失败，则记录错误。
        shm_ptr_ = mmap(nullptr, SHM_SIZE, PROT_READ, MAP_SHARED, shm_fd_, 0);
        if (shm_ptr_ == MAP_FAILED) {
            RCLCPP_ERROR(this->get_logger(), "Failed to map shared memory");
            return;
        }
    }
    void start_server() {
        //创建socket
        int server_fd = socket(AF_INET, SOCK_STREAM, 0);
        if (server_fd == -1) {
            RCLCPP_ERROR(this->get_logger(), "Failed to create socket");
            return;
        }
        //绑定地址和端口
        sockaddr_in server_addr{};
        server_addr.sin_family = AF_INET;
        server_addr.sin_addr.s_addr = INADDR_ANY;
        server_addr.sin_port = htons(MJPEG_PORT);
        if (bind(server_fd, (struct sockaddr*)&server_addr, sizeof(server_addr)) == -1) {
            RCLCPP_ERROR(this->get_logger(), "Failed to bind socket");
            return;
        }
        //监听端口
        if (listen(server_fd, 1000) == -1) {
            RCLCPP_ERROR(this->get_logger(), "Failed to listen on socket");
            return;
        }
        RCLCPP_INFO(this->get_logger(), "Web server running on port %d", MJPEG_PORT);
        //连接客户端
        while (true) {
            int client_fd = accept(server_fd, nullptr, nullptr);
            if (client_fd == -1) {
                RCLCPP_ERROR(this->get_logger(), "Failed to accept client connection");
                continue;
            }
            // 启动一个线程处理客户端请求
            pthread_t client_thread;
            pthread_create(&client_thread, nullptr, &WebVideoServer::handle_client, (void*)client_fd);
        }
    }
private:
    void image_callback(const ros2_camera_streamer::msg::ImageData::SharedPtr msg) {
        // 处理接收到的图像数据
        // 假设图像数据存储在 msg->data 中
        memcpy(shm_ptr_, msg->data.data(), msg->data.size());
    }
    static void* handle_client(void* arg) {
        int client_fd = (int)arg;
        std::string response_header = "HTTP/1.1 200 OK\r\nContent-Type: multipart/x-mixed-replace; boundary=frame\r\n\r\n";
        write(client_fd, response_header.c_str(), response_header.size());
        while (true) {
            // 读取共享内存中的数据并将其编码为MJPEG
            std::string frame = get_next_frame();
            if (frame.empty()) {
                continue;
            }
            std::stringstream ss;
            ss << "--frame\r\nContent-Type: image/jpeg\r\nContent-Length: " << frame.size() << "\r\n\r\n";
            write(client_fd, ss.str().c_str(), ss.str().size());
            write(client_fd, frame.c_str(), frame.size());
            write(client_fd, "\r\n", 2);
        }
    }
    std::string get_next_frame() {
        // 读取共享内存中的数据并编码为MJPEG
        if (shm_ptr_ == nullptr) {
            return "";
        }
        // 使用 libjpeg 编码图像
        struct jpeg_compress_struct cinfo;
        struct jpeg_error_mgr jerr;
        std::stringstream encoded_frame;
        cinfo.err = jpeg_std_error(&jerr);
        jpeg_create_compress(&cinfo);
        encoded_frame.clear();
        jpeg_stdio_dest(&cinfo, &encoded_frame);
        int width = 640;  
        int height = 480; 
        unsigned char* image_data = (unsigned char*)shm_ptr_;
        cinfo.image_width = width;
        cinfo.image_height = height;
        cinfo.input_components = 3;
        cinfo.in_color_space = JCS_RGB;
        jpeg_set_quality(&cinfo, 75, TRUE);
        jpeg_start_compress(&cinfo, TRUE);
        JSAMPROW row_pointer[1];
        while (cinfo.next_scanline < cinfo.image_height) {
            row_pointer[0] = &image_data[cinfo.next_scanline * width * 3];
            jpeg_write_scanlines(&cinfo, row_pointer, 1);
        }
        jpeg_finish_compress(&cinfo);
        jpeg_destroy_compress(&cinfo);

        return encoded_frame.str();
    }
    rclcpp::Subscription<ros2_camera_streamer::msg::ImageData>::SharedPtr subscriber_;
    int shm_fd_;
    void* shm_ptr_;
};
int main(int argc, char** argv) {
    rclcpp::init(argc, argv);
    auto server = std::make_shared<WebVideoServer>();
    server->start_server();
    rclcpp::spin(server);
    rclcpp::shutdown();
    return 0;
}