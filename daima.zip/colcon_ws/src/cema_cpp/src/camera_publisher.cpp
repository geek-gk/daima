#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/image.hpp>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <semaphore.h>
#include <iostream>
#include <memory>
#include <cstring>
#include <v4l2.h>
#include "cema_cpp/msg/image_data.hpp"  // 自定义消息

#define CAMERA_DEVICE "/dev/video0"
#define SHM_SIZE 4096  // 共享内存大小
#define SHM_NAME "/camera_shm"

class CameraPublisher : public rclcpp::Node {
public:
    CameraPublisher() : Node("camera_publisher") {
        publisher_ = this->create_publisher<ros2_camera_streamer::msg::ImageData>("camera_image", 10);
        // 创建共享内存
        shm_fd_ = shm_open(SHM_NAME, O_CREAT | O_RDWR, S_IRUSR | S_IWUSR);
        if (shm_fd_ == -1) {
            RCLCPP_ERROR(this->get_logger(), "Failed to create shared memory");
            return;
        }
        if (ftruncate(shm_fd_, SHM_SIZE) == -1) {
            RCLCPP_ERROR(this->get_logger(), "Failed to set shared memory size");
            return;
        }
        shared_memory_ = mmap(nullptr, SHM_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, shm_fd_, 0);
        if (shared_memory_ == MAP_FAILED) {
            RCLCPP_ERROR(this->get_logger(), "Failed to map shared memory");
            return;
        }

        // 使用V4L2接口打开摄像头
        open_camera();
    }
    //结束时释放内存
    ~CameraPublisher() {
        if (shared_memory_) {
            munmap(shared_memory_, SHM_SIZE);
        }
        if (shm_fd_ != -1) {
            close(shm_fd_);
        }
    }

    void capture_and_publish() {
        // 捕获图像
        capture_image();

        // 填充ROS2自定义消息
        auto msg = ros2_camera_streamer::msg::ImageData();
        msg.shm_id = SHM_NAME;
        msg.width = image_width_;
        msg.height = image_height_;
        msg.format = "NV12";  
        msg.timestamp = this->get_clock()->now();

        publisher_->publish(msg);
    }

private:
    void open_camera() {
        // 初始化V4L2摄像头设备
        int fd = open(CAMERA_DEVICE, O_RDWR);
        if (fd == -1) {
            RCLCPP_ERROR(this->get_logger(), "Unable to open camera device");
            return;
        }
        // 设置视频格式为NV12
        struct v4l2_format fmt;
        memset(&fmt, 0, sizeof(fmt));
        fmt.type = V4L2_BUF_TYPE_VIDEO_CAPTURE;
        fmt.fmt.pix.width = 1920;
        fmt.fmt.pix.height = 1080;
        fmt.fmt.pix.pixelformat = V4L2_PIX_FMT_NV12;
        if (ioctl(fd, VIDIOC_S_FMT, &fmt) == -1) {
            RCLCPP_ERROR(this->get_logger(), "Unable to set video format");
            close(fd);
            return;
        }
        image_width_ = fmt.fmt.pix.width;
        image_height_ = fmt.fmt.pix.height;
    }

    void capture_image() {
        // 捕获图像数据并存储到共享内存
        // 通过V4L2获取数据后存储到共享内存
        memset(shared_memory_, 0, SHM_SIZE);
        v4l2_capture(shared_memory_);//捕获图像并保存
    }

    int shm_fd_;
    void* shared_memory_;
    int image_width_;
    int image_height_;
    rclcpp::Publisher<ros2_camera_streamer::msg::ImageData>::SharedPtr publisher_;
};

int main(int argc, char** argv) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<CameraPublisher>());
    rclcpp::shutdown();
    return 0;
}
